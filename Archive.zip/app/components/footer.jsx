

const Footer = () => {
  return (
    <div className='absolute bottom-0 w-full p-3 bg-[#7abf17] items-center text-white text-center'>
      <p>Copyright Fajrin Yusuf Muttaqin. 2023.</p>
    </div>
  )
};

export default Footer;
